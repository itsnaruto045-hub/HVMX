"use server"

import { cookies } from "next/headers"

export interface User {
  id: string
  email: string
  isAdmin: boolean
  createdAt: string
}

export interface VM {
  id: string
  name: string
  os: "debian" | "kali" | "ubuntu" | "redhat"
  status: "running" | "stopped" | "pending"
  userId: string
  cpu: number
  ram: number
  createdAt: string
}

// Mock database (in real app, use actual database)
const users: User[] = []
const vms: VM[] = []

export async function isRegistrationOpen(): Promise<boolean> {
  return users.length === 0
}

export async function registerUser(email: string, password: string) {
  if (users.length > 0) {
    return { success: false, error: "Registration is closed. Admin has already been created." }
  }

  const existingUser = users.find((u) => u.email === email)
  if (existingUser) {
    return { success: false, error: "User already exists" }
  }

  const user: User = {
    id: `user_${Date.now()}`,
    email,
    isAdmin: true,
    createdAt: new Date().toISOString(),
  }

  users.push(user)

  const cookieStore = await cookies()
  cookieStore.set("user_session", JSON.stringify(user), {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    maxAge: 60 * 60 * 24 * 7,
  })

  return { success: true, user, isAdmin: true }
}

export async function loginUser(email: string, password: string) {
  const user = users.find((u) => u.email === email)
  if (!user) {
    return { success: false, error: "Invalid credentials" }
  }

  const cookieStore = await cookies()
  cookieStore.set("user_session", JSON.stringify(user), {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    maxAge: 60 * 60 * 24 * 7,
  })

  return { success: true, user }
}

export async function getCurrentUser(): Promise<User | null> {
  const cookieStore = await cookies()
  const session = cookieStore.get("user_session")
  if (!session) return null

  try {
    return JSON.parse(session.value)
  } catch {
    return null
  }
}

export async function logoutUser() {
  const cookieStore = await cookies()
  cookieStore.delete("user_session")
  return { success: true }
}

export async function getAllUsers(): Promise<User[]> {
  return users
}

export async function createVM(userId: string, name: string, os: VM["os"], cpu = 2, ram = 2048) {
  const vm: VM = {
    id: `vm_${Date.now()}`,
    name,
    os,
    status: "pending",
    userId,
    cpu,
    ram,
    createdAt: new Date().toISOString(),
  }

  vms.push(vm)

  setTimeout(() => {
    vm.status = "running"
  }, 2000)

  return { success: true, vm }
}

export async function getVMsByUser(userId: string): Promise<VM[]> {
  return vms.filter((vm) => vm.userId === userId)
}

export async function getAllVMs(): Promise<VM[]> {
  return vms
}

export async function toggleVMStatus(vmId: string) {
  const vm = vms.find((v) => v.id === vmId)
  if (!vm) return { success: false, error: "VM not found" }

  vm.status = vm.status === "running" ? "stopped" : "running"
  return { success: true, vm }
}

export async function deleteVM(vmId: string) {
  const index = vms.findIndex((v) => v.id === vmId)
  if (index === -1) return { success: false, error: "VM not found" }

  vms.splice(index, 1)
  return { success: true }
}

export async function assignVMToUser(vmId: string, userId: string) {
  const vm = vms.find((v) => v.id === vmId)
  if (!vm) return { success: false, error: "VM not found" }

  vm.userId = userId
  return { success: true, vm }
}

export async function updateVMResources(vmId: string, cpu: number, ram: number) {
  const vm = vms.find((v) => v.id === vmId)
  if (!vm) return { success: false, error: "VM not found" }

  vm.cpu = Math.max(1, Math.min(16, cpu))
  vm.ram = Math.max(512, Math.min(65536, ram))
  return { success: true, vm }
}
