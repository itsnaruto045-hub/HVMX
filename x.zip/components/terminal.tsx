"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { TerminalIcon } from "lucide-react"
import type { VM } from "@/lib/auth"

interface TerminalProps {
  vm: VM
}

interface CommandOutput {
  command: string
  output: string
  timestamp: Date
}

export function Terminal({ vm }: TerminalProps) {
  const [command, setCommand] = useState("")
  const [history, setHistory] = useState<CommandOutput[]>([
    {
      command: "system",
      output: `Connected to ${vm.name} (${vm.os})\nVM ID: ${vm.id}\nCPU: ${vm.cpu} cores | RAM: ${vm.ram} MB\nStatus: ${vm.status}\n\nType 'help' for available commands.`,
      timestamp: new Date(),
    },
  ])
  const [commandHistory, setCommandHistory] = useState<string[]>([])
  const [historyIndex, setHistoryIndex] = useState(-1)
  const scrollRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [history])

  const executeCommand = (cmd: string) => {
    const trimmedCmd = cmd.trim().toLowerCase()
    const parts = trimmedCmd.split(" ")
    const mainCmd = parts[0]
    const args = parts.slice(1)
    let output = ""

    switch (mainCmd) {
      case "help":
        output = `Available commands:
VM Management:
  status              - Show VM status and uptime
  info                - Show VM information and specs
  start               - Start the VM
  stop                - Stop the VM
  restart             - Restart the VM
  reboot              - Reboot the VM (same as restart)

System Monitoring:
  ps                  - List running processes
  top                 - Show resource usage (CPU, Memory, Disk I/O)
  network             - Show network configuration
  disk                - Show disk usage and partitions
  logs                - Show system logs
  sysinfo             - Display system information
  uptime              - Show system uptime

File Operations:
  ls [path]           - List directory contents
  mkdir [name]        - Create directory
  rmdir [name]        - Remove directory
  touch [file]        - Create file

User Management:
  whoami              - Show current user
  users               - List system users
  useradd [user]      - Add new user
  userdel [user]      - Delete user

Network:
  ping [host]         - Ping a host
  ifconfig            - Show interface configuration
  route               - Show routing table
  netstat             - Show network statistics

System:
  clear               - Clear terminal
  history             - Show command history
  date                - Show current date and time
  exit                - Close terminal
  help                - Show this help message`
        break

      case "status":
        output = `VM Status: ${vm.status.toUpperCase()}
Hostname: ${vm.name}
Kernel: Linux 5.10.0-${Math.floor(Math.random() * 20)}
Uptime: ${Math.floor(Math.random() * 1000)} days ${Math.floor(Math.random() * 24)} hours
Load Average: ${(Math.random() * 2).toFixed(2)}, ${(Math.random() * 2).toFixed(2)}, ${(Math.random() * 2).toFixed(2)}
Current Users: ${Math.floor(Math.random() * 5) + 1}`
        break

      case "info":
        output = `=== Virtual Machine Information ===
Name:               ${vm.name}
Operating System:   ${vm.os.toUpperCase()}
VM ID:              ${vm.id}
Status:             ${vm.status}
Created:            ${new Date(vm.createdAt).toLocaleString()}

=== Hardware Resources ===
CPU Cores:          ${vm.cpu}
RAM:                ${vm.ram} MB (${(vm.ram / 1024).toFixed(2)} GB)
Max CPU Threads:    ${vm.cpu * 2}
Swap Memory:        ${vm.ram / 2} MB

=== Network ===
IP Address:         192.168.1.${Math.floor(Math.random() * 255)}
Gateway:            192.168.1.1
DNS:                8.8.8.8, 8.8.4.4

=== Performance ===
Avg Load:           ${(Math.random() * vm.cpu).toFixed(2)}
CPU Usage:          ${Math.floor(Math.random() * 50)}%
Memory Usage:       ${Math.floor(Math.random() * 80)}%`
        break

      case "start":
        output =
          vm.status === "running"
            ? "Error: VM is already running"
            : "Starting VM...\n[OK] VM started successfully\n[OK] All services initialized"
        break

      case "stop":
        output =
          vm.status === "stopped"
            ? "Error: VM is already stopped"
            : "Stopping VM...\n[OK] Services stopped\n[OK] VM halted successfully"
        break

      case "restart":
      case "reboot":
        output =
          "Initiating restart...\n[OK] Services stopped\n[OK] VM rebooting\n[OK] System boot successful\n[OK] All services online"
        break

      case "ps":
        output = `PID   USER     %CPU  %MEM  COMMAND
1     root      0.0   0.1   /sbin/init
245   root      0.1   0.2   /lib/systemd/systemd-journald
312   root      0.5   1.2   sshd
445   user      2.3   3.5   node /app/server.js
523   user      0.2   0.8   bash
634   root      1.2   0.4   nginx
712   user      0.0   0.1   python3 script.py
801   user      3.1   2.5   docker
902   root      0.0   0.0   /sbin/agetty`
        break

      case "top":
        output = `top - ${new Date().toLocaleTimeString()} up ${Math.floor(Math.random() * 100)} days, load average: ${(Math.random() * 2).toFixed(2)}, ${(Math.random() * 2).toFixed(2)}, ${(Math.random() * 2).toFixed(2)}

Tasks: ${Math.floor(Math.random() * 50) + 10} total, ${Math.floor(Math.random() * 10) + 1} running, ${Math.floor(Math.random() * 40) + 5} sleeping

%Cpu(s): ${Math.floor(Math.random() * 30)}% us, ${Math.floor(Math.random() * 10)}% sy, ${Math.floor(Math.random() * 5)}% ni, ${Math.floor(Math.random() * 60)}% id, ${Math.floor(Math.random() * 5)}% wa, ${Math.floor(Math.random() * 3)}% hi, ${Math.floor(Math.random() * 3)}% si, 0.0% st

MiB Mem: ${(vm.ram / 1024).toFixed(1)} total, ${((vm.ram / 1024) * Math.random()).toFixed(1)} used, ${((vm.ram / 1024) * Math.random()).toFixed(1)} free, ${((vm.ram / 1024) * Math.random()).toFixed(1)} buffers
Disk I/O: Read ${Math.floor(Math.random() * 500)} MB/s | Write ${Math.floor(Math.random() * 300)} MB/s`
        break

      case "network":
        output = `Network Interfaces:
eth0: flags=UP,BROADCAST,RUNNING,MULTICAST
      inet 192.168.1.${Math.floor(Math.random() * 255)}  netmask 255.255.255.0
      inet6 fe80::1/64
      RX packets ${Math.floor(Math.random() * 1000000)}  TX packets ${Math.floor(Math.random() * 1000000)}
      RX bytes ${Math.floor(Math.random() * 500)} MB  TX bytes ${Math.floor(Math.random() * 500)} MB

lo: flags=UP,LOOPBACK,RUNNING
    inet 127.0.0.1  netmask 255.0.0.0
    RX packets 1000  TX packets 1000`
        break

      case "disk":
        output = `Filesystem     Size      Used      Avail     Use%  Mounted on
/dev/sda1      ${vm.ram * 2}G      ${Math.floor(vm.ram * 0.6)}G      ${Math.floor(vm.ram * 1.4)}G      30%   /
/dev/sda2      ${vm.ram}G        ${Math.floor(vm.ram * 0.3)}G      ${Math.floor(vm.ram * 0.7)}G      30%   /home
tmpfs          4.0G        1.2G        2.8G      30%   /tmp
/dev/sdb1      ${vm.ram * 4}G      ${Math.floor(vm.ram * 1.5)}G      ${Math.floor(vm.ram * 2.5)}G      37%   /data`
        break

      case "logs":
        output = `[${new Date().toLocaleTimeString()}] System boot successful
[${new Date(Date.now() - 60000).toLocaleTimeString()}] Network interface eth0 UP
[${new Date(Date.now() - 120000).toLocaleTimeString()}] SSH service started (port 22)
[${new Date(Date.now() - 180000).toLocaleTimeString()}] All services operational
[${new Date(Date.now() - 240000).toLocaleTimeString()}] Kernel modules loaded
[${new Date(Date.now() - 300000).toLocaleTimeString()}] Database service initialized
[${new Date(Date.now() - 360000).toLocaleTimeString()}] Memory checks completed`
        break

      case "sysinfo":
        output = `=== System Information ===
OS:                 ${vm.os === "debian" ? "Debian GNU/Linux" : vm.os === "ubuntu" ? "Ubuntu" : vm.os === "kali" ? "Kali Linux" : "Red Hat Enterprise Linux"}
Kernel:             Linux 5.10.0-${Math.floor(Math.random() * 30)}
Architecture:       x86_64
Hostname:           ${vm.name}
Uptime:             ${Math.floor(Math.random() * 365)} days
Boot Time:          ${new Date(Date.now() - Math.random() * 86400000).toLocaleString()}

CPU Info:
  Processors:       ${vm.cpu}
  Cores per CPU:    1
  Threads per Core: 2

Memory:
  Total:            ${vm.ram} MB
  Used:             ${Math.floor(vm.ram * Math.random())} MB
  Available:        ${Math.floor(vm.ram * Math.random())} MB`
        break

      case "uptime":
        const days = Math.floor(Math.random() * 365)
        const hours = Math.floor(Math.random() * 24)
        const minutes = Math.floor(Math.random() * 60)
        output = `${new Date().toLocaleTimeString()} up ${days} days, ${hours} hours, ${minutes} minutes, ${Math.floor(Math.random() * 5) + 1} user(s), load average: ${(Math.random() * 2).toFixed(2)}, ${(Math.random() * 2).toFixed(2)}, ${(Math.random() * 2).toFixed(2)}`
        break

      case "ls":
        const path = args.length > 0 ? args.join(" ") : "/"
        output = `Contents of ${path}:
drwxr-xr-x  root  root  4096  Dec 3 10:23  .
drwxr-xr-x  root  root  4096  Dec 3 10:23  ..
drwxr-xr-x  root  root  4096  Dec 3 10:23  bin
drwxr-xr-x  root  root  4096  Dec 3 10:23  boot
drwxr-xr-x  root  root  4096  Dec 3 10:23  dev
drwxr-xr-x  root  root  4096  Dec 3 10:23  etc
drwxr-xr-x  root  root  4096  Dec 3 10:23  home
drwxr-xr-x  root  root  4096  Dec 3 10:23  root
drwxr-xr-x  root  root  4096  Dec 3 10:23  usr
drwxr-xr-x  root  root  4096  Dec 3 10:23  var`
        break

      case "mkdir":
        if (args.length === 0) {
          output = "Error: mkdir requires a directory name\nUsage: mkdir [directory_name]"
        } else {
          output = `[OK] Directory '${args.join(" ")}' created successfully`
        }
        break

      case "touch":
        if (args.length === 0) {
          output = "Error: touch requires a file name\nUsage: touch [file_name]"
        } else {
          output = `[OK] File '${args.join(" ")}' created`
        }
        break

      case "whoami":
        output = "root"
        break

      case "users":
        output = `root
daemon
bin
sys
user
guest
www-data`
        break

      case "ping":
        if (args.length === 0) {
          output = "Error: ping requires a hostname\nUsage: ping [hostname]"
        } else {
          const host = args[0]
          output = `PING ${host} (${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)})
64 bytes from ${host}: icmp_seq=1 ttl=64 time=${Math.floor(Math.random() * 50)}ms
64 bytes from ${host}: icmp_seq=2 ttl=64 time=${Math.floor(Math.random() * 50)}ms
64 bytes from ${host}: icmp_seq=3 ttl=64 time=${Math.floor(Math.random() * 50)}ms
--- ${host} statistics ---
3 packets transmitted, 3 received, 0% packet loss`
        }
        break

      case "ifconfig":
        output = `eth0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>
        inet 192.168.1.${Math.floor(Math.random() * 255)}  netmask 255.255.255.0  broadcast 192.168.1.255
        inet6 fe80::1  prefixlen 64  scopeid 0x20<link>
        ether 02:42:ac:11:00:${Math.floor(Math.random() * 255)}
        RX packets 500000  bytes 250000000
        TX packets 400000  bytes 200000000

lo: flags=73<UP,LOOPBACK,RUNNING>
    inet 127.0.0.1  netmask 255.0.0.0`
        break

      case "date":
        output = new Date().toString()
        break

      case "history":
        if (commandHistory.length === 0) {
          output = "No command history"
        } else {
          output = commandHistory.map((cmd, idx) => `${idx + 1}  ${cmd}`).join("\n")
        }
        break

      case "clear":
        setHistory([])
        return

      case "exit":
        output = "Closing terminal session..."
        break

      case "":
        return

      default:
        output = `Command not found: ${trimmedCmd}\nType 'help' for available commands.`
    }

    setHistory([
      ...history,
      {
        command: cmd,
        output,
        timestamp: new Date(),
      },
    ])
    setCommandHistory([...commandHistory, cmd])
    setHistoryIndex(-1)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (command.trim()) {
      executeCommand(command)
      setCommand("")
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowUp") {
      e.preventDefault()
      if (commandHistory.length > 0) {
        const newIndex = historyIndex + 1
        if (newIndex < commandHistory.length) {
          setHistoryIndex(newIndex)
          setCommand(commandHistory[commandHistory.length - 1 - newIndex])
        }
      }
    } else if (e.key === "ArrowDown") {
      e.preventDefault()
      if (historyIndex > 0) {
        const newIndex = historyIndex - 1
        setHistoryIndex(newIndex)
        setCommand(commandHistory[commandHistory.length - 1 - newIndex])
      } else if (historyIndex === 0) {
        setHistoryIndex(-1)
        setCommand("")
      }
    }
  }

  return (
    <Card className="border-primary/20 h-full">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <TerminalIcon className="h-5 w-5 text-primary" />
          Command Line Interface
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="bg-black/50 font-mono text-sm">
          <ScrollArea className="h-[500px] p-4" ref={scrollRef}>
            <div className="space-y-3">
              {history.map((entry, index) => (
                <div key={index} className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-primary">root@{vm.name}:~$</span>
                    <span className="text-foreground">{entry.command}</span>
                  </div>
                  <pre className="text-muted-foreground whitespace-pre-wrap pl-4">{entry.output}</pre>
                </div>
              ))}
            </div>
          </ScrollArea>
          <form onSubmit={handleSubmit} className="border-t border-border p-4">
            <div className="flex items-center gap-2">
              <span className="text-primary font-mono text-sm">root@{vm.name}:~$</span>
              <Input
                ref={inputRef}
                value={command}
                onChange={(e) => setCommand(e.target.value)}
                onKeyDown={handleKeyDown}
                className="flex-1 border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 font-mono text-sm"
                placeholder="Enter command..."
                autoComplete="off"
                autoFocus
              />
            </div>
          </form>
        </div>
      </CardContent>
    </Card>
  )
}
