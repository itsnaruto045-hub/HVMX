import { redirect } from "next/navigation"
import { getCurrentUser, getAllVMs } from "@/lib/auth"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Terminal } from "@/components/terminal"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default async function VMDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser()
  const { id } = await params

  if (!user) {
    redirect("/")
  }

  const vms = await getAllVMs()
  const vm = vms.find((v) => v.id === id)

  if (!vm) {
    redirect("/dashboard/vms")
  }

  if (!user.isAdmin && vm.userId !== user.id) {
    redirect("/dashboard/vms")
  }

  return (
    <DashboardLayout user={user}>
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Link href="/dashboard/vms">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-balance">{vm.name}</h1>
            <p className="text-muted-foreground capitalize">
              {vm.os} - {vm.status}
            </p>
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <Terminal vm={vm} />
          </div>

          <div className="space-y-4">
            <Card className="border-primary/20">
              <CardHeader>
                <CardTitle className="text-base">VM Details</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">VM ID</span>
                  <span className="font-mono text-xs">{vm.id}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Status</span>
                  <span className="capitalize font-medium">{vm.status}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Operating System</span>
                  <span className="capitalize">{vm.os}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">CPU Cores</span>
                  <span>{vm.cpu}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">RAM</span>
                  <span>{vm.ram} MB</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Created</span>
                  <span className="text-xs">{new Date(vm.createdAt).toLocaleDateString()}</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </DashboardLayout>
  )
}
