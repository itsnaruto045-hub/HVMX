import { redirect } from "next/navigation"
import { getCurrentUser } from "@/lib/auth"
import { DashboardLayout } from "@/components/dashboard-layout"
import { VMManager } from "@/components/vm-manager"

export default async function VMsPage() {
  const user = await getCurrentUser()

  if (!user) {
    redirect("/")
  }

  return (
    <DashboardLayout user={user}>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-balance">Virtual Machines</h1>
          <p className="text-muted-foreground">Create and manage your VMs without Docker</p>
        </div>

        <VMManager user={user} />
      </div>
    </DashboardLayout>
  )
}
