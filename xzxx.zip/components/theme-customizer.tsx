"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Upload, Palette, ImageIcon, RotateCcw } from "lucide-react"
import { updateThemeConfig } from "@/lib/auth"
import type { ThemeConfig } from "@/lib/auth"

interface ThemeCustomizerProps {
  currentConfig: ThemeConfig
  onUpdate: (config: ThemeConfig) => void
}

export function ThemeCustomizer({ currentConfig, onUpdate }: ThemeCustomizerProps) {
  const [logoPreview, setLogoPreview] = useState<string | undefined>(currentConfig.logoUrl)
  const [backgroundPreview, setBackgroundPreview] = useState<string | undefined>(currentConfig.backgroundUrl)
  const [bgColor, setBgColor] = useState(currentConfig.backgroundColor || "#1a1a2e")
  const [isSaving, setIsSaving] = useState(false)

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (event) => {
        const result = event.target?.result as string
        setLogoPreview(result)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleBackgroundUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (event) => {
        const result = event.target?.result as string
        setBackgroundPreview(result)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSave = async () => {
    setIsSaving(true)
    const newConfig: ThemeConfig = {
      logoUrl: logoPreview,
      backgroundUrl: backgroundPreview,
      backgroundColor: bgColor,
    }
    await updateThemeConfig(newConfig)
    onUpdate(newConfig)
    setIsSaving(false)
  }

  const handleReset = () => {
    setLogoPreview(currentConfig.logoUrl)
    setBackgroundPreview(currentConfig.backgroundUrl)
    setBgColor(currentConfig.backgroundColor || "#1a1a2e")
  }

  return (
    <div className="space-y-6">
      <Card className="border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ImageIcon className="h-5 w-5 text-primary" />
            Logo Customization
          </CardTitle>
          <CardDescription>Upload a custom logo for the panel header</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {logoPreview && (
            <div className="p-4 bg-secondary/50 rounded-lg flex items-center justify-center h-20">
              <img src={logoPreview || "/placeholder.svg"} alt="Logo preview" className="max-h-16 max-w-xs" />
            </div>
          )}
          <div className="flex gap-2">
            <label className="flex-1">
              <input type="file" accept="image/*" onChange={handleLogoUpload} className="hidden" />
              <Button asChild variant="outline" className="w-full cursor-pointer bg-transparent">
                <span>
                  <Upload className="h-4 w-4 mr-2" />
                  Upload Logo
                </span>
              </Button>
            </label>
            {logoPreview && (
              <Button
                variant="ghost"
                onClick={() => setLogoPreview(undefined)}
                className="text-destructive hover:bg-destructive/10"
              >
                Remove
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      <Card className="border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Palette className="h-5 w-5 text-primary" />
            Background Customization
          </CardTitle>
          <CardDescription>Set a custom background image or solid color</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm font-medium block mb-2">Background Color</label>
            <div className="flex gap-2 items-center">
              <input
                type="color"
                value={bgColor}
                onChange={(e) => setBgColor(e.target.value)}
                className="h-10 w-20 rounded cursor-pointer border border-border"
              />
              <span className="font-mono text-sm text-muted-foreground">{bgColor}</span>
            </div>
          </div>

          <div className="border-t border-border pt-4">
            <label className="text-sm font-medium block mb-2">Or Upload Background Image</label>
            {backgroundPreview && (
              <div className="mb-4 p-4 bg-secondary/50 rounded-lg h-32 overflow-hidden">
                <img
                  src={backgroundPreview || "/placeholder.svg"}
                  alt="Background preview"
                  className="w-full h-full object-cover"
                />
              </div>
            )}
            <div className="flex gap-2">
              <label className="flex-1">
                <input type="file" accept="image/*" onChange={handleBackgroundUpload} className="hidden" />
                <Button asChild variant="outline" className="w-full cursor-pointer bg-transparent">
                  <span>
                    <Upload className="h-4 w-4 mr-2" />
                    Upload Background
                  </span>
                </Button>
              </label>
              {backgroundPreview && (
                <Button
                  variant="ghost"
                  onClick={() => setBackgroundPreview(undefined)}
                  className="text-destructive hover:bg-destructive/10"
                >
                  Remove
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex gap-2">
        <Button onClick={handleSave} disabled={isSaving} className="flex-1">
          {isSaving ? "Saving..." : "Save Changes"}
        </Button>
        <Button variant="outline" onClick={handleReset}>
          <RotateCcw className="h-4 w-4 mr-2" />
          Reset
        </Button>
      </div>
    </div>
  )
}
