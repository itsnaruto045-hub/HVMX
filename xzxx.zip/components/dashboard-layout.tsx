"use client"

import type React from "react"

import { type ReactNode, useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import type { User } from "@/lib/auth"
import { logoutUser, getThemeConfig } from "@/lib/auth"
import { Server, Terminal, Users, Settings, LogOut, Menu, X } from "lucide-react"
import type { ThemeConfig } from "@/lib/auth"

interface DashboardLayoutProps {
  children: ReactNode
  user: User
}

export function DashboardLayout({ children, user }: DashboardLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [themeConfig, setThemeConfig] = useState<ThemeConfig | null>(null)
  const router = useRouter()

  useEffect(() => {
    async function loadTheme() {
      const config = await getThemeConfig()
      setThemeConfig(config)
    }
    loadTheme()
  }, [])

  const handleLogout = async () => {
    await logoutUser()
    router.push("/")
    router.refresh()
  }

  const navItems = [
    { href: "/dashboard", icon: Server, label: "Dashboard" },
    { href: "/dashboard/vms", icon: Terminal, label: "Virtual Machines" },
    ...(user.isAdmin ? [{ href: "/dashboard/users", icon: Users, label: "Users" }] : []),
    { href: "/dashboard/settings", icon: Settings, label: "Settings" },
  ]

  const backgroundStyle: React.CSSProperties = themeConfig?.backgroundUrl
    ? {
        backgroundImage: `url('${themeConfig.backgroundUrl}')`,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }
    : themeConfig?.backgroundColor
      ? { background: themeConfig.backgroundColor }
      : {}

  return (
    <div className="min-h-screen nebula-bg" style={backgroundStyle}>
      {/* Mobile sidebar backdrop */}
      {sidebarOpen && (
        <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Sidebar */}
      <aside
        className={`
        fixed top-0 left-0 z-50 h-full w-64 bg-card border-r border-border
        transform transition-transform duration-300 ease-in-out
        lg:translate-x-0
        ${sidebarOpen ? "translate-x-0" : "-translate-x-full"}
      `}
      >
        <div className="flex flex-col h-full">
          {/* Header with custom logo */}
          <div className="p-6 border-b border-border">
            <div className="flex items-center justify-between gap-2">
              {themeConfig?.logoUrl ? (
                <img src={themeConfig.logoUrl || "/placeholder.svg"} alt="Logo" className="h-8 max-w-32" />
              ) : (
                <h2 className="text-xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                  HVM Panel
                </h2>
              )}
              <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setSidebarOpen(false)}>
                <X className="h-5 w-5" />
              </Button>
            </div>
            <div className="mt-4 p-3 bg-secondary/50 rounded-lg">
              <p className="text-sm font-medium">{user.email}</p>
              <p className="text-xs text-muted-foreground mt-1">{user.isAdmin ? "Administrator" : "User"}</p>
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex-1 p-4 space-y-2">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-secondary/50 transition-colors"
                onClick={() => setSidebarOpen(false)}
              >
                <item.icon className="h-5 w-5 text-primary" />
                <span>{item.label}</span>
              </Link>
            ))}
          </nav>

          {/* Footer */}
          <div className="p-4 border-t border-border">
            <Button
              variant="ghost"
              className="w-full justify-start text-destructive hover:text-destructive hover:bg-destructive/10"
              onClick={handleLogout}
            >
              <LogOut className="h-5 w-5 mr-3" />
              Logout
            </Button>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <div className="lg:pl-64">
        {/* Top bar */}
        <header className="sticky top-0 z-30 bg-card/80 backdrop-blur-lg border-b border-border">
          <div className="flex items-center justify-between px-4 py-4">
            <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setSidebarOpen(true)}>
              <Menu className="h-5 w-5" />
            </Button>
            <div className="flex-1 lg:flex-none" />
            <div className="flex items-center gap-2">
              <div className="h-2 w-2 rounded-full bg-primary animate-pulse" />
              <span className="text-sm text-muted-foreground">Port 3000</span>
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="p-4 md:p-6 lg:p-8">{children}</main>
      </div>
    </div>
  )
}
