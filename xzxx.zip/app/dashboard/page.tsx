import { redirect } from "next/navigation"
import { getCurrentUser } from "@/lib/auth"
import { DashboardLayout } from "@/components/dashboard-layout"
import { UserManagement } from "@/components/user-management"
import { VMOverview } from "@/components/vm-overview"

export default async function DashboardPage() {
  const user = await getCurrentUser()

  if (!user) {
    redirect("/")
  }

  return (
    <DashboardLayout user={user}>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-balance">Dashboard</h1>
          <p className="text-muted-foreground">{user.isAdmin ? "Admin Control Center" : "Your Virtual Machines"}</p>
        </div>

        <VMOverview user={user} />

        {user.isAdmin && <UserManagement />}
      </div>
    </DashboardLayout>
  )
}
