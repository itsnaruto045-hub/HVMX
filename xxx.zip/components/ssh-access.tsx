"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import type { VM } from "@/lib/auth"
import { Copy, Terminal, Eye, EyeOff } from "lucide-react"

interface SSHAccessProps {
  vm: VM
}

export function SSHAccess({ vm }: SSHAccessProps) {
  const [showPassword, setShowPassword] = useState(false)
  const [copied, setCopied] = useState<string | null>(null)

  const sshCommand = `ssh -p ${vm.sshPort} ${vm.sshUser}@localhost`

  const handleCopy = (text: string, type: string) => {
    navigator.clipboard.writeText(text)
    setCopied(type)
    setTimeout(() => setCopied(null), 2000)
  }

  return (
    <Card className="border-primary/20">
      <CardHeader>
        <div className="flex items-center gap-2">
          <Terminal className="h-5 w-5 text-primary" />
          <div>
            <CardTitle className="text-lg">SSH Access</CardTitle>
            <CardDescription>Connect to your VM via SSH</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* SSH Connection Info */}
        <div className="space-y-3 p-4 bg-secondary/30 rounded-lg border border-primary/10">
          <div className="space-y-2">
            <Label className="text-xs font-semibold">Host</Label>
            <div className="flex gap-2">
              <Input value="localhost" readOnly className="font-mono text-xs bg-background/50" />
              <Button size="sm" variant="outline" onClick={() => handleCopy("localhost", "host")} className="px-2">
                <Copy className="h-3 w-3" />
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label className="text-xs font-semibold">Port</Label>
              <div className="flex gap-2">
                <Input value={vm.sshPort} readOnly className="font-mono text-xs bg-background/50" />
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleCopy(vm.sshPort.toString(), "port")}
                  className="px-2"
                >
                  <Copy className="h-3 w-3" />
                </Button>
              </div>
            </div>
            <div className="space-y-2">
              <Label className="text-xs font-semibold">Username</Label>
              <div className="flex gap-2">
                <Input value={vm.sshUser} readOnly className="font-mono text-xs bg-background/50" />
                <Button size="sm" variant="outline" onClick={() => handleCopy(vm.sshUser, "user")} className="px-2">
                  <Copy className="h-3 w-3" />
                </Button>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-xs font-semibold">Password</Label>
            <div className="flex gap-2">
              <Input
                type={showPassword ? "text" : "password"}
                value={vm.sshPassword}
                readOnly
                className="font-mono text-xs bg-background/50"
              />
              <Button size="sm" variant="outline" onClick={() => setShowPassword(!showPassword)} className="px-2">
                {showPassword ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleCopy(vm.sshPassword, "password")}
                className="px-2"
              >
                <Copy className="h-3 w-3" />
              </Button>
            </div>
          </div>
        </div>

        {/* SSH Command */}
        <div className="space-y-2">
          <Label className="text-xs font-semibold">SSH Command</Label>
          <div className="flex gap-2">
            <code className="flex-1 p-2 bg-background/50 rounded border border-primary/10 font-mono text-xs break-all">
              {sshCommand}
            </code>
            <Button size="sm" variant="outline" onClick={() => handleCopy(sshCommand, "command")}>
              <Copy className="h-3 w-3" />
            </Button>
          </div>
        </div>

        {/* Connection Instructions */}
        <div className="p-3 bg-accent/10 rounded-lg border border-accent/20 text-xs space-y-2">
          <p className="font-semibold text-accent-foreground">Connection Instructions:</p>
          <ol className="space-y-1 text-muted-foreground list-decimal list-inside">
            <li>Copy the SSH command above</li>
            <li>Open your terminal/command prompt</li>
            <li>Paste the command and press Enter</li>
            <li>When prompted, enter the password above</li>
          </ol>
        </div>

        {vm.status === "running" ? (
          <Badge className="w-full justify-center bg-primary">Ready for SSH Connection</Badge>
        ) : (
          <Badge variant="outline" className="w-full justify-center bg-muted">
            VM must be running to connect
          </Badge>
        )}
      </CardContent>
    </Card>
  )
}
