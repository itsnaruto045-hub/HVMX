"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { type User, type VM, getAllUsers, getAllVMs, assignVMToUser } from "@/lib/auth"
import { Link2 } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export function VMAssignment() {
  const [users, setUsers] = useState<User[]>([])
  const [vms, setVMs] = useState<VM[]>([])
  const [selectedVM, setSelectedVM] = useState("")
  const [selectedUser, setSelectedUser] = useState("")
  const [loading, setLoading] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    const loadData = async () => {
      const [usersData, vmsData] = await Promise.all([getAllUsers(), getAllVMs()])
      setUsers(usersData)
      setVMs(vmsData)
    }
    loadData()
  }, [])

  const handleAssign = async () => {
    if (!selectedVM || !selectedUser) return

    setLoading(true)
    try {
      await assignVMToUser(selectedVM, selectedUser)
      const vmsData = await getAllVMs()
      setVMs(vmsData)
      setSelectedVM("")
      setSelectedUser("")

      toast({
        title: "VM assigned successfully",
        description: "The VM has been assigned to the selected user",
      })
    } catch (error) {
      toast({
        title: "Assignment failed",
        description: "Failed to assign VM to user",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card className="border-primary/20">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Link2 className="h-5 w-5 text-primary" />
          VM Assignment
        </CardTitle>
        <CardDescription>Assign virtual machines to users</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid gap-4 md:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="vm-select">Select VM</Label>
            <Select value={selectedVM} onValueChange={setSelectedVM}>
              <SelectTrigger id="vm-select" className="bg-secondary/50">
                <SelectValue placeholder="Choose a VM" />
              </SelectTrigger>
              <SelectContent>
                {vms.map((vm) => (
                  <SelectItem key={vm.id} value={vm.id}>
                    {vm.name} ({vm.os})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="user-select">Select User</Label>
            <Select value={selectedUser} onValueChange={setSelectedUser}>
              <SelectTrigger id="user-select" className="bg-secondary/50">
                <SelectValue placeholder="Choose a user" />
              </SelectTrigger>
              <SelectContent>
                {users.map((user) => (
                  <SelectItem key={user.id} value={user.id}>
                    {user.email} {user.isAdmin && "(Admin)"}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        <Button onClick={handleAssign} disabled={!selectedVM || !selectedUser || loading} className="w-full">
          {loading ? "Assigning..." : "Assign VM to User"}
        </Button>
      </CardContent>
    </Card>
  )
}
