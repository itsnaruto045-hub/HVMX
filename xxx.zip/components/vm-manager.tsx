"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { type User, type VM, getVMsByUser, getAllVMs, createVM, toggleVMStatus, deleteVM } from "@/lib/auth"
import { Server, Play, Square, Trash2, Monitor, Plus, Cpu, HardDrive } from "lucide-react"
import Link from "next/link"

interface VMManagerProps {
  user: User
}

export function VMManager({ user }: VMManagerProps) {
  const [vms, setVMs] = useState<VM[]>([])
  const [loading, setLoading] = useState(true)
  const [createDialogOpen, setCreateDialogOpen] = useState(false)
  const [newVMName, setNewVMName] = useState("")
  const [newVMOS, setNewVMOS] = useState<VM["os"]>("debian")
  const [newVMCPU, setNewVMCPU] = useState(2)
  const [newVMRAM, setNewVMRAM] = useState(2048)
  const [creating, setCreating] = useState(false)

  const loadVMs = async () => {
    const data = user.isAdmin ? await getAllVMs() : await getVMsByUser(user.id)
    setVMs(data)
    setLoading(false)
  }

  useEffect(() => {
    loadVMs()
  }, [user])

  const handleCreateVM = async () => {
    if (!newVMName.trim()) return

    setCreating(true)
    try {
      await createVM(user.id, newVMName, newVMOS, newVMCPU, newVMRAM)
      await loadVMs()
      setCreateDialogOpen(false)
      setNewVMName("")
      setNewVMOS("debian")
      setNewVMCPU(2)
      setNewVMRAM(2048)
    } catch (error) {
      console.error("Failed to create VM:", error)
    } finally {
      setCreating(false)
    }
  }

  const handleToggleStatus = async (vmId: string) => {
    await toggleVMStatus(vmId)
    await loadVMs()
  }

  const handleDeleteVM = async (vmId: string) => {
    if (confirm("Are you sure you want to delete this VM?")) {
      await deleteVM(vmId)
      await loadVMs()
    }
  }

  const getOSIcon = (os: VM["os"]) => {
    const icons = {
      debian: "🌀",
      kali: "🐉",
      ubuntu: "🟠",
      redhat: "🎩",
    }
    return icons[os]
  }

  const getStatusColor = (status: VM["status"]) => {
    const colors = {
      running: "bg-primary text-primary-foreground",
      stopped: "bg-muted text-muted-foreground",
      pending: "bg-accent text-accent-foreground",
    }
    return colors[status]
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2">
              <Plus className="h-4 w-4" />
              Create VM
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Create New Virtual Machine</DialogTitle>
              <DialogDescription>Deploy a new VM without Docker for better performance</DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="vm-name">VM Name</Label>
                <Input
                  id="vm-name"
                  placeholder="my-dev-server"
                  value={newVMName}
                  onChange={(e) => setNewVMName(e.target.value)}
                  className="bg-secondary/50"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="vm-os">Operating System</Label>
                <Select value={newVMOS} onValueChange={(value) => setNewVMOS(value as VM["os"])}>
                  <SelectTrigger id="vm-os" className="bg-secondary/50">
                    <SelectValue placeholder="Select OS" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="debian">Debian</SelectItem>
                    <SelectItem value="kali">Kali Linux</SelectItem>
                    <SelectItem value="ubuntu">Ubuntu</SelectItem>
                    <SelectItem value="redhat">RedHat</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="vm-cpu">CPU Cores</Label>
                  <div className="flex items-center gap-2">
                    <Cpu className="h-4 w-4 text-primary" />
                    <Input
                      id="vm-cpu"
                      type="number"
                      min="1"
                      max="16"
                      value={newVMCPU}
                      onChange={(e) => setNewVMCPU(Math.max(1, Number.parseInt(e.target.value) || 1))}
                      className="bg-secondary/50"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="vm-ram">RAM (MB)</Label>
                  <div className="flex items-center gap-2">
                    <HardDrive className="h-4 w-4 text-accent" />
                    <Input
                      id="vm-ram"
                      type="number"
                      min="512"
                      step="512"
                      value={newVMRAM}
                      onChange={(e) => setNewVMRAM(Math.max(512, Number.parseInt(e.target.value) || 512))}
                      className="bg-secondary/50"
                    />
                  </div>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button onClick={handleCreateVM} disabled={creating || !newVMName.trim()} className="w-full">
                {creating ? "Creating..." : "Create VM"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {loading ? (
        <Card className="border-primary/20">
          <CardContent className="py-8">
            <p className="text-center text-muted-foreground">Loading virtual machines...</p>
          </CardContent>
        </Card>
      ) : vms.length === 0 ? (
        <Card className="border-primary/20">
          <CardContent className="py-12 text-center">
            <Server className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-lg font-medium mb-2">No Virtual Machines</p>
            <p className="text-muted-foreground mb-4">Create your first VM to get started</p>
            <Button onClick={() => setCreateDialogOpen(true)} className="gap-2">
              <Plus className="h-4 w-4" />
              Create VM
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {vms.map((vm) => (
            <Card key={vm.id} className="border-primary/20 hover:border-primary/40 transition-colors">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">{getOSIcon(vm.os)}</span>
                    <div>
                      <CardTitle className="text-lg">{vm.name}</CardTitle>
                      <CardDescription className="capitalize">{vm.os}</CardDescription>
                    </div>
                  </div>
                  <Badge className={getStatusColor(vm.status)}>{vm.status}</Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground flex items-center gap-1">
                      <Cpu className="h-3 w-3" /> CPU:
                    </span>
                    <span className="font-mono">{vm.cpu} cores</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-muted-foreground flex items-center gap-1">
                      <HardDrive className="h-3 w-3" /> RAM:
                    </span>
                    <span className="font-mono">{vm.ram} MB</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">SSH Port:</span>
                    <span className="font-mono">{vm.sshPort}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Created:</span>
                    <span>{new Date(vm.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>

                <div className="flex gap-2 pt-2">
                  <Button
                    size="sm"
                    variant={vm.status === "running" ? "outline" : "default"}
                    className="flex-1 gap-1"
                    onClick={() => handleToggleStatus(vm.id)}
                    disabled={vm.status === "pending"}
                  >
                    {vm.status === "running" ? (
                      <>
                        <Square className="h-3 w-3" />
                        Stop
                      </>
                    ) : (
                      <>
                        <Play className="h-3 w-3" />
                        Start
                      </>
                    )}
                  </Button>
                  <Link href={`/dashboard/vms/${vm.id}`}>
                    <Button size="sm" variant="outline" className="gap-1 bg-transparent">
                      <Monitor className="h-3 w-3" />
                      Access
                    </Button>
                  </Link>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="text-destructive hover:text-destructive hover:bg-destructive/10"
                    onClick={() => handleDeleteVM(vm.id)}
                  >
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
