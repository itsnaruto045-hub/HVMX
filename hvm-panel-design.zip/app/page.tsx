import { redirect } from "next/navigation"
import { getCurrentUser } from "@/lib/auth"
import { AuthForm } from "@/components/auth-form"

export default async function HomePage() {
  const user = await getCurrentUser()

  if (user) {
    redirect("/dashboard")
  }

  return (
    <main className="min-h-screen nebula-bg star-field flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-[url('/cosmic-nebula-stars.jpg')] opacity-10 bg-cover bg-center" />
      <div className="relative z-10 flex flex-col items-center gap-8">
        <div className="text-center space-y-2">
          <h1 className="text-4xl md:text-5xl font-bold text-balance bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
            HVM Panel
          </h1>
          <p className="text-muted-foreground text-lg">Nebula Edition - Hardware Virtual Machine Management</p>
        </div>
        <AuthForm />
      </div>
    </main>
  )
}
