"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { type User, type VM, getVMsByUser, getAllVMs } from "@/lib/auth"
import { Server, Activity, HardDrive, Zap } from "lucide-react"

interface VMOverviewProps {
  user: User
}

export function VMOverview({ user }: VMOverviewProps) {
  const [vms, setVMs] = useState<VM[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadVMs = async () => {
      const data = user.isAdmin ? await getAllVMs() : await getVMsByUser(user.id)
      setVMs(data)
      setLoading(false)
    }
    loadVMs()
  }, [user])

  const stats = {
    total: vms.length,
    running: vms.filter((vm) => vm.status === "running").length,
    stopped: vms.filter((vm) => vm.status === "stopped").length,
    pending: vms.filter((vm) => vm.status === "pending").length,
  }

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      <Card className="border-primary/20">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-sm font-medium">Total VMs</CardTitle>
          <Server className="h-4 w-4 text-primary" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{stats.total}</div>
          <p className="text-xs text-muted-foreground mt-1">All virtual machines</p>
        </CardContent>
      </Card>

      <Card className="border-primary/20">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-sm font-medium">Running</CardTitle>
          <Activity className="h-4 w-4 text-primary" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-primary">{stats.running}</div>
          <p className="text-xs text-muted-foreground mt-1">Active instances</p>
        </CardContent>
      </Card>

      <Card className="border-primary/20">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-sm font-medium">Stopped</CardTitle>
          <HardDrive className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{stats.stopped}</div>
          <p className="text-xs text-muted-foreground mt-1">Inactive instances</p>
        </CardContent>
      </Card>

      <Card className="border-primary/20">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-sm font-medium">Pending</CardTitle>
          <Zap className="h-4 w-4 text-accent" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-accent">{stats.pending}</div>
          <p className="text-xs text-muted-foreground mt-1">Initializing</p>
        </CardContent>
      </Card>
    </div>
  )
}
