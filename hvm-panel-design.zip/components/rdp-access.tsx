"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import type { VM } from "@/lib/auth"
import { Monitor, Copy, Check, Download, ExternalLink, Shield } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface RDPAccessProps {
  vm: VM
}

export function RDPAccess({ vm }: RDPAccessProps) {
  const [copied, setCopied] = useState(false)
  const { toast } = useToast()

  const rdpHost = typeof window !== "undefined" ? window.location.hostname : "localhost"
  const rdpConnection = `${rdpHost}:${vm.rdpPort}`

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
    toast({
      title: "Copied to clipboard",
      description: "RDP connection string has been copied",
    })
  }

  const downloadRDPFile = () => {
    const rdpContent = `full address:s:${rdpConnection}
prompt for credentials:i:1
administrative session:i:1
screen mode id:i:2
use multimon:i:0
desktopwidth:i:1920
desktopheight:i:1080
session bpp:i:32
compression:i:1
keyboardhook:i:2
audiocapturemode:i:0
videoplaybackmode:i:1
connection type:i:7
networkautodetect:i:1
bandwidthautodetect:i:1
displayconnectionbar:i:1
enableworkspacereconnect:i:0
disable wallpaper:i:0
allow font smoothing:i:1
allow desktop composition:i:1
disable full window drag:i:0
disable menu anims:i:0
disable themes:i:0
disable cursor setting:i:0
bitmapcachepersistenable:i:1
audiomode:i:0
redirectprinters:i:1
redirectcomports:i:0
redirectsmartcards:i:1
redirectclipboard:i:1
redirectposdevices:i:0
autoreconnection enabled:i:1
authentication level:i:2
negotiate security layer:i:1
remoteapplicationmode:i:0
alternate shell:s:
shell working directory:s:
gatewayhostname:s:
gatewayusagemethod:i:4
gatewaycredentialssource:i:4
gatewayprofileusagemethod:i:0
promptcredentialonce:i:0
gatewaybrokeringtype:i:0
use redirection server name:i:0
rdgiskdcproxy:i:0
kdcproxyname:s:`

    const blob = new Blob([rdpContent], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${vm.name}.rdp`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    toast({
      title: "RDP file downloaded",
      description: `${vm.name}.rdp has been saved to your downloads`,
    })
  }

  return (
    <Card className="border-primary/20 h-full">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Monitor className="h-5 w-5 text-primary" />
              RDP Access
            </CardTitle>
            <CardDescription>Remote Desktop Protocol connection details</CardDescription>
          </div>
          <Badge variant={vm.status === "running" ? "default" : "secondary"}>{vm.status}</Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <Tabs defaultValue="quick" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="quick">Quick Connect</TabsTrigger>
            <TabsTrigger value="advanced">Advanced</TabsTrigger>
          </TabsList>

          <TabsContent value="quick" className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="rdp-host">Host Address</Label>
              <div className="flex gap-2">
                <Input id="rdp-host" value={rdpConnection} readOnly className="bg-secondary/50 font-mono" />
                <Button size="icon" variant="outline" onClick={() => copyToClipboard(rdpConnection)}>
                  {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="rdp-username">Username</Label>
                <Input id="rdp-username" value="root" readOnly className="bg-secondary/50" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="rdp-port">Port</Label>
                <Input id="rdp-port" value={vm.rdpPort} readOnly className="bg-secondary/50 font-mono" />
              </div>
            </div>

            <div className="pt-4 space-y-2">
              <Button className="w-full gap-2" onClick={downloadRDPFile} disabled={vm.status !== "running"}>
                <Download className="h-4 w-4" />
                Download RDP File
              </Button>
              <Button variant="outline" className="w-full gap-2 bg-transparent" disabled={vm.status !== "running"}>
                <ExternalLink className="h-4 w-4" />
                Open in Browser
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="advanced" className="space-y-4">
            <div className="space-y-3 text-sm">
              <div className="flex items-center justify-between p-3 bg-secondary/30 rounded-lg">
                <span className="text-muted-foreground">Connection Type</span>
                <span className="font-medium">RDP 10.0</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-secondary/30 rounded-lg">
                <span className="text-muted-foreground">Resolution</span>
                <span className="font-medium">1920x1080</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-secondary/30 rounded-lg">
                <span className="text-muted-foreground">Color Depth</span>
                <span className="font-medium">32-bit</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-secondary/30 rounded-lg">
                <span className="text-muted-foreground">Audio</span>
                <span className="font-medium">Enabled</span>
              </div>
              <div className="flex items-center justify-between p-3 bg-secondary/30 rounded-lg">
                <span className="text-muted-foreground">Clipboard</span>
                <span className="font-medium">Bidirectional</span>
              </div>
            </div>

            <div className="p-4 bg-primary/10 border border-primary/20 rounded-lg space-y-2">
              <div className="flex items-center gap-2 text-primary">
                <Shield className="h-4 w-4" />
                <span className="font-medium text-sm">Security Notice</span>
              </div>
              <p className="text-xs text-muted-foreground">
                RDP connections are encrypted using TLS 1.3. Network Level Authentication (NLA) is enabled for enhanced
                security.
              </p>
            </div>
          </TabsContent>
        </Tabs>

        {vm.status !== "running" && (
          <div className="p-4 bg-accent/10 border border-accent/20 rounded-lg">
            <p className="text-sm text-center text-muted-foreground">VM must be running to establish RDP connection</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
