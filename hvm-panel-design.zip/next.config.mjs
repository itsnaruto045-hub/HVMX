/** @type {import('next').NextConfig} */
const nextConfig = {
  env: {
    PORT: '3000',
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    unoptimized: true,
  },
}

export default nextConfig
