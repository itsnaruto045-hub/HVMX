"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { TerminalIcon } from "lucide-react"
import type { VM } from "@/lib/auth"

interface TerminalProps {
  vm: VM
}

interface CommandOutput {
  command: string
  output: string
  timestamp: Date
}

export function Terminal({ vm }: TerminalProps) {
  const [command, setCommand] = useState("")
  const [history, setHistory] = useState<CommandOutput[]>([
    {
      command: "system",
      output: `Connected to ${vm.name} (${vm.os})\nVM ID: ${vm.id}\nRDP Port: ${vm.rdpPort}\nStatus: ${vm.status}\n\nType 'help' for available commands.`,
      timestamp: new Date(),
    },
  ])
  const [commandHistory, setCommandHistory] = useState<string[]>([])
  const [historyIndex, setHistoryIndex] = useState(-1)
  const scrollRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [history])

  const executeCommand = (cmd: string) => {
    const trimmedCmd = cmd.trim().toLowerCase()
    let output = ""

    switch (trimmedCmd) {
      case "help":
        output = `Available commands:
  help        - Show this help message
  status      - Show VM status
  info        - Show VM information
  start       - Start the VM
  stop        - Stop the VM
  restart     - Restart the VM
  ps          - List running processes
  top         - Show resource usage
  network     - Show network configuration
  disk        - Show disk usage
  clear       - Clear terminal
  exit        - Close terminal`
        break
      case "status":
        output = `VM Status: ${vm.status.toUpperCase()}\nUptime: ${Math.floor(Math.random() * 1000)} seconds`
        break
      case "info":
        output = `VM Information:
  Name: ${vm.name}
  OS: ${vm.os}
  ID: ${vm.id}
  RDP Port: ${vm.rdpPort}
  Status: ${vm.status}
  Created: ${new Date(vm.createdAt).toLocaleString()}`
        break
      case "start":
        output = vm.status === "running" ? "VM is already running" : "Starting VM...\n[OK] VM started successfully"
        break
      case "stop":
        output = vm.status === "stopped" ? "VM is already stopped" : "Stopping VM...\n[OK] VM stopped successfully"
        break
      case "restart":
        output = "Restarting VM...\n[OK] VM restarted successfully"
        break
      case "ps":
        output = `PID   USER     COMMAND
1     root     /sbin/init
245   root     sshd
312   root     nginx
445   user     node
523   user     bash`
        break
      case "top":
        output = `CPU Usage: ${Math.floor(Math.random() * 50)}%
Memory Usage: ${Math.floor(Math.random() * 80)}%
Disk I/O: ${Math.floor(Math.random() * 100)} MB/s
Network: ${Math.floor(Math.random() * 1000)} KB/s`
        break
      case "network":
        output = `Network Configuration:
  Interface: eth0
  IP Address: 192.168.1.${Math.floor(Math.random() * 255)}
  Netmask: 255.255.255.0
  Gateway: 192.168.1.1
  DNS: 8.8.8.8`
        break
      case "disk":
        output = `Filesystem     Size  Used  Avail  Use%
/dev/sda1       50G   ${Math.floor(Math.random() * 30)}G   ${50 - Math.floor(Math.random() * 30)}G   ${Math.floor(Math.random() * 60)}%
tmpfs          4.0G  1.2G  2.8G   30%`
        break
      case "clear":
        setHistory([])
        return
      case "exit":
        output = "Closing terminal session..."
        break
      case "":
        return
      default:
        output = `Command not found: ${trimmedCmd}\nType 'help' for available commands.`
    }

    setHistory([
      ...history,
      {
        command: cmd,
        output,
        timestamp: new Date(),
      },
    ])
    setCommandHistory([...commandHistory, cmd])
    setHistoryIndex(-1)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (command.trim()) {
      executeCommand(command)
      setCommand("")
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowUp") {
      e.preventDefault()
      if (commandHistory.length > 0) {
        const newIndex = historyIndex + 1
        if (newIndex < commandHistory.length) {
          setHistoryIndex(newIndex)
          setCommand(commandHistory[commandHistory.length - 1 - newIndex])
        }
      }
    } else if (e.key === "ArrowDown") {
      e.preventDefault()
      if (historyIndex > 0) {
        const newIndex = historyIndex - 1
        setHistoryIndex(newIndex)
        setCommand(commandHistory[commandHistory.length - 1 - newIndex])
      } else if (historyIndex === 0) {
        setHistoryIndex(-1)
        setCommand("")
      }
    }
  }

  return (
    <Card className="border-primary/20 h-full">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <TerminalIcon className="h-5 w-5 text-primary" />
          Command Line Interface
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="bg-black/50 font-mono text-sm">
          <ScrollArea className="h-[400px] p-4" ref={scrollRef}>
            <div className="space-y-3">
              {history.map((entry, index) => (
                <div key={index} className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-primary">root@{vm.name}:~$</span>
                    <span className="text-foreground">{entry.command}</span>
                  </div>
                  <pre className="text-muted-foreground whitespace-pre-wrap pl-4">{entry.output}</pre>
                </div>
              ))}
            </div>
          </ScrollArea>
          <form onSubmit={handleSubmit} className="border-t border-border p-4">
            <div className="flex items-center gap-2">
              <span className="text-primary font-mono text-sm">root@{vm.name}:~$</span>
              <Input
                ref={inputRef}
                value={command}
                onChange={(e) => setCommand(e.target.value)}
                onKeyDown={handleKeyDown}
                className="flex-1 border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 font-mono text-sm"
                placeholder="Enter command..."
                autoComplete="off"
                autoFocus
              />
            </div>
          </form>
        </div>
      </CardContent>
    </Card>
  )
}
