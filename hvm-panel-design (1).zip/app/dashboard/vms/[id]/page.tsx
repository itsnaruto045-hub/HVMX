import { redirect } from "next/navigation"
import { getCurrentUser, getAllVMs } from "@/lib/auth"
import { DashboardLayout } from "@/components/dashboard-layout"
import { Terminal } from "@/components/terminal"
import { RDPAccess } from "@/components/rdp-access"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default async function VMDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser()
  const { id } = await params

  if (!user) {
    redirect("/")
  }

  const vms = await getAllVMs()
  const vm = vms.find((v) => v.id === id)

  if (!vm) {
    redirect("/dashboard/vms")
  }

  if (!user.isAdmin && vm.userId !== user.id) {
    redirect("/dashboard/vms")
  }

  return (
    <DashboardLayout user={user}>
      <div className="space-y-6">
        <div className="flex items-center gap-4">
          <Link href="/dashboard/vms">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-balance">{vm.name}</h1>
            <p className="text-muted-foreground capitalize">
              {vm.os} - {vm.status}
            </p>
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <Terminal vm={vm} />
          <RDPAccess vm={vm} />
        </div>
      </div>
    </DashboardLayout>
  )
}
